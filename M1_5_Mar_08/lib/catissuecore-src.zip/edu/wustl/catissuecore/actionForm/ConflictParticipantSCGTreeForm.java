package edu.wustl.catissuecore.actionForm;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

public class ConflictParticipantSCGTreeForm extends AbstractActionForm{
	public int getFormId()
	{	
		return 0;
	}

	protected void reset()
	{
	
	}

	public void setAllValues(AbstractDomainObject abstractDomain)
	{		
		
	}

}
