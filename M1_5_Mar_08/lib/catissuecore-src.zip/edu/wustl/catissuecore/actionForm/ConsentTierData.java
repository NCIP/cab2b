package edu.wustl.catissuecore.actionForm;

import java.util.Collection;


public interface ConsentTierData
{
 	public Collection getConsentTiers();
 	public String getConsentTierMap();
}
