/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.wustl.catissuecore.annotations;

import java.util.List;

import edu.wustl.common.beans.NameValueBean;



public interface ICPCondition
{
    
    public  List  getCollectionProtocolList(Long entityInstanceId);
    

}
