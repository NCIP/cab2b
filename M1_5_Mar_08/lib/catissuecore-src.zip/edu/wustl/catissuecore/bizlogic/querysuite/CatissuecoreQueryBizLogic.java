/**
 * 
 */

package edu.wustl.catissuecore.bizlogic.querysuite;

import edu.wustl.common.querysuite.bizLogic.QueryBizLogic;
import edu.wustl.common.querysuite.queryobject.IParameterizedQuery;

/**
 * @author chetan_patil
 * @created Sep 13, 2007, 7:39:46 PM
 */
public class CatissuecoreQueryBizLogic extends QueryBizLogic<IParameterizedQuery>
{

	/**
	 * Default Constructor
	 */
	public CatissuecoreQueryBizLogic()
	{

	}
	
}
