package edu.common.dynamicextensions.domaininterface;

/**
 * This is a boolean type of primitive attribute.
 * @author geetika_bangard
 */
public interface BooleanTypeInformationInterface extends AttributeTypeInformationInterface
{

    

  
}
