/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright://TODO</p>
 *@author Vishvesh Mulay
 *@version 1.0
 */

package edu.common.dynamicextensions.entitymanager;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import edu.common.dynamicextensions.domain.Association;
import edu.common.dynamicextensions.domain.DomainObjectFactory;
import edu.common.dynamicextensions.domain.Entity;
import edu.common.dynamicextensions.domaininterface.AssociationInterface;
import edu.common.dynamicextensions.domaininterface.AttributeInterface;
import edu.common.dynamicextensions.domaininterface.EntityInterface;
import edu.common.dynamicextensions.domaininterface.RoleInterface;
import edu.common.dynamicextensions.exception.DynamicExtensionsApplicationException;
import edu.common.dynamicextensions.exception.DynamicExtensionsSystemException;
import edu.common.dynamicextensions.util.DynamicExtensionsBaseTestCase;
import edu.common.dynamicextensions.util.global.Constants.AssociationDirection;
import edu.common.dynamicextensions.util.global.Constants.AssociationType;
import edu.common.dynamicextensions.util.global.Constants.Cardinality;

public class TestEntityManagerTemp extends DynamicExtensionsBaseTestCase
{

	/**
	 * 
	 */
	public TestEntityManagerTemp()
	{
		super();
		//TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0 name
	 */
	public TestEntityManagerTemp(String arg0)
	{
		super(arg0);
		//TODO Auto-generated constructor stub
	}

	/**
	 * @see edu.common.dynamicextensions.util.DynamicExtensionsBaseTestCase#setUp()
	 */
	protected void setUp()
	{
		System.setProperty("log4j.appender.stdout","org.apache.log4j.ConsoleAppender");
		System.setProperty("log4j.rootLogger","DEBUG");
		
		super.setUp();
	}

	/**
	 * @see edu.common.dynamicextensions.util.DynamicExtensionsBaseTestCase#tearDown()
	 */
	protected void tearDown()
	{
		super.tearDown();
	}


	/**
	 * @param associationType associationType
	 * @param name name
	 * @param minCard  minCard
	 * @param maxCard maxCard
	 * @return  RoleInterface
	 */
	private RoleInterface getRole(AssociationType associationType, String name, Cardinality minCard,
			Cardinality maxCard)
	{
		RoleInterface role = DomainObjectFactory.getInstance().createRole();
		role.setAssociationsType(associationType);
		role.setName(name);
		role.setMinimumCardinality(minCard);
		role.setMaximumCardinality(maxCard);
		return role;
	}

	
	  /**
     * 
     */
 
    public void testEditEntity()
    {
        Entity entity = new Entity();
        entity.setName("Stock Quote");
        EntityManagerInterface entityManagerInterface = EntityManager.getInstance();
 
        try
        {
            EntityInterface savedEntity = entityManagerInterface.persistEntity(entity);
 
            //Edit entity
            AttributeInterface floatAtribute = DomainObjectFactory.getInstance()
                    .createFloatAttribute();
            floatAtribute.setName("Price");
 
            savedEntity.addAbstractAttribute(floatAtribute);
            EntityInterface editedEntity = entityManagerInterface.persistEntity(savedEntity);
 
            Map dataValue = new HashMap();
            dataValue.put(floatAtribute, "15.90");
            entityManagerInterface.insertData(editedEntity, dataValue);
 
            //Edit entity
            AttributeInterface floatAtribute1 = DomainObjectFactory.getInstance()
                    .createFloatAttribute();
            floatAtribute.setName("NewPrice");
            editedEntity.addAbstractAttribute(floatAtribute1);
 
            java.sql.ResultSetMetaData metadata = executeQueryForMetadata("select * from "
                    + editedEntity.getTableProperties().getName());
            assertEquals(metadata.getColumnCount(), 2);
 
            EntityInterface newEditedEntity = entityManagerInterface.persistEntity(editedEntity);
            dataValue.put(floatAtribute1, "16.90");
            entityManagerInterface.insertData(newEditedEntity, dataValue);
 
            metadata = executeQueryForMetadata("select * from "
                    + editedEntity.getTableProperties().getName());
            assertEquals(metadata.getColumnCount(), 3);
 
        }
        catch (DynamicExtensionsSystemException e)
        {
            
            e.printStackTrace();
            fail();
        }
        catch (DynamicExtensionsApplicationException e)
        {
            e.printStackTrace();
            fail();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            fail();
        }
 
    }	 
}
