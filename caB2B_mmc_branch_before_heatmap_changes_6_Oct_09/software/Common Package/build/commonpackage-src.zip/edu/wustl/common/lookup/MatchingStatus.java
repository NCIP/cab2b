package edu.wustl.common.lookup;

public enum MatchingStatus 
{
	EXACT, PARTIAL, NOMATCH;
}

