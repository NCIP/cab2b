/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author Vishvesh Mulay
 *@version 1.0
 */ 
package edu.common.dynamicextensions.domaininterface;

import java.io.Serializable;



public interface DynamicExtensionBaseDomainObjectInterface extends Serializable
{

}
