
package edu.common.dynamicextensions.domaininterface;

/**
 * This is a primitive attribute of type short.Using this information a column of type short is prepared.
 * @author geetika_bangard
 */
public interface ShortTypeInformationInterface extends NumericTypeInformationInterface
{
}
