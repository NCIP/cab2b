
package edu.common.dynamicextensions.domaininterface.userinterface;

public interface SelectInterface
{

}
