package edu.common.dynamicextensions.entitymanager;

import edu.wustl.common.util.logger.Logger;
import gov.nih.nci.cagrid.common.Utils;
import gov.nih.nci.cagrid.metadata.common.UMLClass;
import gov.nih.nci.cagrid.metadata.dataservice.DomainModel;
import gov.nih.nci.cagrid.metadata.dataservice.UMLAssociation;
import gov.nih.nci.cagrid.metadata.dataservice.UMLGeneralization;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * This class parses the domain model for an application.<br>
 * First it gets the domain model (in XML format) located at given file URL.
 * Then using caGrid metadata classes it convert this XML to list of UML classes and UMLAssociation.
 * An instance of this class is tied to a particular DomainModel instance.
 * Additionally, this class uses the caGRID's definition of a DomainModel and their respective API(s)
 * 
 * @author Chandrakant Talele
 * @author munesh
 * @version 1.0
 */
public class DomainModelParser1 {
    /**
     * The DomainModel to Parse and Process
     */
    protected DomainModel domainModel;

    /**
     * This constructor ties instance of this class to a single domain model.<br>
     * It takes the URL as parameter where the DomainModel.xml is available.<br>
     * Once created, an instance of DomainModelParser is tied to a particular
     * DomainModel
     * 
     * @param xmlFilePath The URL from where to retrieve the DomainModel.xml
     *            and create a DomainModel Object.
     * Throws the exception occured during getting / parsing the domain model XML as RuntimeException. 
     */
    public DomainModelParser1(String xmlFilePath) {
        
        try {
            domainModel = (DomainModel) Utils.deserializeDocument(xmlFilePath, DomainModel.class);
        } catch (Exception e) {
           // throw new RuntimeException("Unable to parse domain model XML file.",e,ErrorCodeConstants.GR_0001);
        }
    }
    /**
     * Gets the DomainModel associated with this Parser.
     * @return model - The entire domain model.
     */
    public DomainModel getDomainModel() {
        return domainModel;
    }

    /**
     * Returns the UMLAssociations in the DomainModel
     * @return UMLAssociation[] - Array of UMLAssociation instances.
     */
    public UMLAssociation[] getUmlAssociations() {
        return domainModel.getExposedUMLAssociationCollection().getUMLAssociation();
    }

    /**
     * Returns the UMLClasses in the DomainModel
     * @return UMLClass[]- Array of UMLClass instances
     */
    public UMLClass[] getUmlClasses() {
        return domainModel.getExposedUMLClassCollection().getUMLClass();
    }
    /**
     * @return Map with key as umlId of parent class and value as list of umlId of children classes.
     */
    public Map<String,List<String>> getParentVsChildrenMap() {
        UMLGeneralization[] umlGeneralizations = domainModel.getUmlGeneralizationCollection().getUMLGeneralization();
        if (umlGeneralizations != null) {
           
            HashMap<String, List<String>> parentIdVsChildrenIds = new HashMap<String, List<String>>(umlGeneralizations.length);
            for (UMLGeneralization umlGeneralization : umlGeneralizations) {
                String childClass = umlGeneralization.getSubClassReference().getRefid();
                String parentClass = umlGeneralization.getSuperClassReference().getRefid();
                List<String> children = parentIdVsChildrenIds.get(parentClass);
                if (children == null) {
                    children = new ArrayList<String>();
                    parentIdVsChildrenIds.put(parentClass, children);
                }
                children.add(childClass);
            }
            return parentIdVsChildrenIds;
        }
        
        return new HashMap<String, List<String>>(0);
    }
}