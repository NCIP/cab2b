package edu.common.dynamicextensions.entitymanager;

import edu.common.dynamicextensions.domain.DomainObjectFactory;
import edu.common.dynamicextensions.domain.SemanticAnnotatableInterface;
import edu.common.dynamicextensions.domaininterface.SemanticPropertyInterface;
import gov.nih.nci.cagrid.metadata.common.SemanticMetadata;


public class DomainModelProcessorUtil
{

	 /**
     * Stores the SemanticMetadata to the owner which can be class or attribute
     * @param owner EntityInterface OR AttributeInterface
     * @param semanticMetadataArr Semantic Metadata array to set.
     */
    public static void setSemanticMetadata(SemanticAnnotatableInterface owner, SemanticMetadata[] semanticMetadataArr) {
        if(semanticMetadataArr==null) {
            return;
        }
        DomainObjectFactory deFactory = DomainObjectFactory.getInstance();
        for (int i = 0; i < semanticMetadataArr.length; i++) {
            SemanticPropertyInterface semanticProp = deFactory.createSemanticProperty();
            semanticProp.setSequenceNumber(i);
            semanticProp.setConceptCode(semanticMetadataArr[i].getConceptCode());
            semanticProp.setTerm(semanticMetadataArr[i].getConceptName());
            owner.addSemanticProperty(semanticProp);
        }
    }
}
