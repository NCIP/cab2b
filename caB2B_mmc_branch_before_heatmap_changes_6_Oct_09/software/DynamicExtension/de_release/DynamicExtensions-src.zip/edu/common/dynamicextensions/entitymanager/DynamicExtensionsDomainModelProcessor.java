
package edu.common.dynamicextensions.entitymanager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import edu.common.dynamicextensions.domain.DateAttributeTypeInformation;
import edu.common.dynamicextensions.domaininterface.AbstractAttributeInterface;
import edu.common.dynamicextensions.domaininterface.AttributeInterface;
import edu.common.dynamicextensions.domaininterface.AttributeTypeInformationInterface;
import edu.common.dynamicextensions.domaininterface.EntityInterface;
import edu.common.dynamicextensions.domaininterface.UserDefinedDEInterface;
import edu.common.dynamicextensions.domaininterface.userinterface.ContainerInterface;
import edu.common.dynamicextensions.domaininterface.userinterface.ControlInterface;
import edu.common.dynamicextensions.domaininterface.userinterface.TextFieldInterface;
import edu.common.dynamicextensions.exception.DynamicExtensionsApplicationException;
import edu.common.dynamicextensions.exception.DynamicExtensionsSystemException;
import edu.wustl.cab2b.server.path.BaseDomainModelProecessor;
import edu.wustl.cab2b.server.path.DomainModelParser;
import gov.nih.nci.cagrid.metadata.common.UMLClass;
/**
 * 
 * @author sujay_narkar
 *
 */
public class DynamicExtensionsDomainModelProcessor extends BaseDomainModelProecessor
{

	/**
	 * 
	 *
	 */
	public DynamicExtensionsDomainModelProcessor()
	{
		super();
	}

	/**
	 * 
	 * @param parser
	 * @param applicationName
	 */
	public DynamicExtensionsDomainModelProcessor(DomainModelParser parser, String applicationName)
	{
		super(parser, applicationName);
	}
	
	/**
	 * 
	 * @param entityInterface
	 * @return
	 */
	protected void createContainer(EntityInterface entityInterface,UMLClass umlClass)
	{
		ContainerInterface containerInterface = deFactory.createContainer();
		containerInterface.setCaption(entityInterface.getName());
		containerInterface.setEntity(entityInterface);
		Collection<AbstractAttributeInterface> abstractAttributeCollection = entityInterface
				.getAbstractAttributeCollection();
		Integer sequenceNumber = new Integer(0);
		ControlInterface controlInterface;
		for (AbstractAttributeInterface abstractAttributeInterface : abstractAttributeCollection)
		{
			controlInterface = getControlForAttribute(abstractAttributeInterface);
			sequenceNumber++;
			controlInterface.setSequenceNumber(sequenceNumber);
			containerInterface.addControl(controlInterface);
		}
		persistContainer(containerInterface,umlClass);
	}
	
	/**
	 * 
	 * @param abstractAttributeInterface
	 * @return
	 */
	ControlInterface getControlForAttribute(AbstractAttributeInterface abstractAttributeInterface)
	{
		AttributeInterface attributeInterface = (AttributeInterface) abstractAttributeInterface;
		AttributeTypeInformationInterface attributeTypeInformation = attributeInterface
				.getAttributeTypeInformation();
		UserDefinedDEInterface userDefinedDEInterface = (UserDefinedDEInterface) attributeTypeInformation
				.getDataElement();
		ControlInterface controlInterface = deFactory.createTextField();;
		if (userDefinedDEInterface != null
				&& userDefinedDEInterface.getPermissibleValueCollection() != null
				&& userDefinedDEInterface.getPermissibleValueCollection().size() > 0)
		{
			controlInterface = deFactory.createListBox();
		}
		else if (attributeTypeInformation instanceof DateAttributeTypeInformation)
		{
			controlInterface = deFactory.createDatePicker();
		}
		else
		{
			controlInterface = deFactory.createTextField();
			((TextFieldInterface) controlInterface).setColumns(0);
		}

		controlInterface.setName(abstractAttributeInterface.getName());
		controlInterface.setCaption(abstractAttributeInterface.getName());
		controlInterface.setAbstractAttribute(abstractAttributeInterface);
		return controlInterface;
	}
	
	/**
	 * 
	 * @param containerInterface
	 * @param umlClass
	 */
	public void persistContainer(ContainerInterface containerInterface,UMLClass umlClass)
	{
		EntityManagerInterface entityManagerInterface  = EntityManager.getInstance();
		
		try
		{
			entityManagerInterface.persistContainer(containerInterface);
			List<ContainerInterface> containerList = new ArrayList<ContainerInterface>();
			containerList.add(containerInterface);
			entityIdVsContainers.put(umlClass.getId(), containerList);
		}
		catch (DynamicExtensionsApplicationException e)
		{
			// TODO Correct the exception handling 
			e.printStackTrace();
		}
		catch (DynamicExtensionsSystemException e)
		{
			// TODO Correct the exception handling 
			e.printStackTrace();
		}
	}
}
