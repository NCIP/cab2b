
package edu.common.dynamicextensions.entitymanager;

import edu.wustl.cab2b.server.path.DomainModelParser;

public class ImportTest
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// DomainModelParser parser = new DomainModelParser("E://caArray-domainModel.xml");
		DomainModelParser parser = new DomainModelParser(
				"E://import_test_xmls//catissue-domainModel//catissue-domainModel_container_controls.xml");
		DynamicExtensionsDomainModelProcessor processor = new DynamicExtensionsDomainModelProcessor(
				parser, "Sujay");

	}

}
