package edu.common.dynamicextensions.entitymanager;

import java.util.Collection;
import java.util.List;

import edu.common.dynamicextensions.util.DynamicExtensionsBaseTestCase;
import edu.wustl.common.beans.NameValueBean;


public class MyTest
extends DynamicExtensionsBaseTestCase implements EntityManagerExceptionConstantsInterface
{

	/**
	 * 
	 */
	public MyTest()
	{
		super();
		//TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0 name
	 */
	public MyTest(String arg0)
	{
		super(arg0);
		//TODO Auto-generated constructor stub
	}

	/**
	 * @see edu.common.dynamicextensions.util.DynamicExtensionsBaseTestCase#setUp()
	 */
	protected void setUp()
	{
		super.setUp();
	}

	/**
	 * @see edu.common.dynamicextensions.util.DynamicExtensionsBaseTestCase#tearDown()
	 */
	protected void tearDown()
	{
		super.tearDown();
	}
	
	
	public void testgetAllEntityGroupBeans()
	{
		EntityManagerInterface entityManager = EntityManager.getInstance();
		
		try
		{
			Collection<NameValueBean> nameValueList = entityManager.getAllEntityGroupBeans();
					
			System.out.println("******************"+nameValueList.size());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			fail();
		}
	}



}
