package edu.wustl.common.lookup;

public enum MatchingStatusForSSNPMI
{
	EXACT, ONEMATCHOTHERNULL,ONEMATCHOTHERMISMATCH, NOMATCH;
}
